package animation;

import animation.demo.AnimationDemo;

public class GameStub  extends AsteroidsGame {

    public int getWidth() {
        return 1000;
    }
    
    public int getHeight() {
        return 1000;
    }

}
